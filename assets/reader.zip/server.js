var connect = require('connect');
connect.createServer(
    connect.static(__dirname)
).listen(8080, '0.0.0.0');
console.log('Server started: http://localhost:8080/');