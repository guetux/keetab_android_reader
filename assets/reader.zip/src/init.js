
function getParam(name) {
  return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search)||[,""])[1].replace(/\+/g, '%20'))||null;
}


$(function () {

  var dataURL = getParam('data');
  if (dataURL === null) {
    dataURL = '/library/alice_in_wonderland.json';
  }

  $.get(dataURL, function (data) {
    KR.init(data);
  });

});