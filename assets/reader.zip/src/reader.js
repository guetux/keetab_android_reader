
KR = {
  fontScale: 1.0
};


KR.createBookData = function (data) {
    return {
        data: data,
        getComponents: function() {
            return data.components || ['anonymous'];
        },
        getContents: function () {
            return data.contents || [];
        },
        applyDocPathURLs: function (html) {
            var doc = new DOMParser().parseFromString(html, "text/xml");
            $('[href]', doc).each(function (i, el) {
                $(el).attr('href', data.doc_path + '/' + $(el).attr('href'));
            });
            $('[src]', doc).each(function (i, el) {
                $(el).attr('src', data.doc_path + '/' + $(el).attr('src'));
            });
            return new XMLSerializer().serializeToString(doc);
        },
        getComponent: function (id, callback) {
            var that = this;
            $.get(data.doc_path + '/' + id, function (html) {
                callback(that.applyDocPathURLs(html));
            });
        },
        getMetaData: function (key) {
          return (data.metadata || {})[key];
        }
    };
}


KR.Panel = function (flipper, evtCallbacks) {
  var panels = {
    forwards: new Monocle.Controls.Panel(),
    backwards: new Monocle.Controls.Panel()
  };

  for (dir in panels) {
    flipper.properties.reader.addControl(panels[dir]);
    panels[dir].listenTo(evtCallbacks);
    panels[dir].setDirection(flipper.constants[dir.toUpperCase()]);
    with (panels[dir].properties.div.style) {
      dir == "forwards" ? right = 0 : left = 0;
    }
  }
  panels.forwards.properties.div.style.width = '3%';
  panels.backwards.properties.div.style.width = '3%';
};

KR.initTitle = function () {
  $('h1.book_title').text(KR.bookData.getMetaData('title'));
};

KR.initTOC = function (bookData, reader) {
  var contents = KR.bookData.getContents();

  var $toc = $('#toc');
  $toc.append('<ol></ol>');
  var $list = $toc.find('ol');

  function chapterBuilder(list, chapter) {
    list.append('<li src="'+chapter.src+'">'+chapter.title+'</li>');
    $item = list.find('li:last-child');
    $item.click(function () {
      KR.reader.skipToChapter($(this).attr('src'));
      KR.toggleToolbar();
    });

    if (chapter.children)  {
      list.append('<ol></ol>');
      $sublist = list.find('ol');
      _.each(chapter.children, function (chapter) {
        chapterBuilder($sublist, chapter);
      });
    }
  }

  _.each(contents, function(chapter) {
    chapterBuilder($list, chapter);
  });
}

KR.initScrubberHider = function () {
  var $scrubber = $('.monelem_controls_scrubber_container');

  function startFadeOutTimer() {
    $scrubber.timer = setTimeout(function () {
      $scrubber.animate({opacity: 0});
    }, 3000);
  }

  function clearFadeOutTimer() {
    if ($scrubber.timer !== undefined) {
      clearTimeout($scrubber.timer);
      delete $scrubber.timer;
    }
  }

  KR.reader.listen('monocle:turn', function () {
    clearFadeOutTimer();
    $scrubber.animate({opacity: 1});
    startFadeOutTimer();
  });

  $scrubber.bind('touchstart mousedown', clearFadeOutTimer);
  $scrubber.bind('touchstart mouseup', startFadeOutTimer);
};

KR.toggleToolbar = function () {
  $('#toolbar').toggleClass('open');
  return false;
};


KR.decreaseFontSize = function () {
  KR.fontScale -= 0.1;
  KR.reader.formatting.setFontScale(KR.fontScale);
}


KR.increaseFontSize = function () {
  KR.fontScale += 0.1;
  KR.reader.formatting.setFontScale(KR.fontScale);
};


KR.bindEvents = function () {
  $('#toggle_toolbar').click(KR.toggleToolbar);
  $('#font_decrease').click(KR.decreaseFontSize);
  $('#font_increase').click(KR.increaseFontSize);
};

KR.swipeEvents = function () {
  window.swipeLeft = function () {
    KR.reader.moveTo({page: KR.reader.getPlace().pageNumber() - 1});
  };

  window.swipeRight = function () {
    KR.reader.moveTo({page: KR.reader.getPlace().pageNumber() + 1});
  };
}

KR.initReader = function () {
  var placeSaver = new Monocle.Controls.PlaceSaver('placesaver');
  KR.reader = Monocle.Reader(
      'reader',
      KR.bookData,
      {panels: KR.Panel, place: placeSaver.savedPlace() },
      function (rdr) {
          // Save place in document
          rdr.addControl(placeSaver, 'invisible');

          // Add progress in document scoller
          var scrubber = new Monocle.Controls.Scrubber(rdr);
          rdr.addControl(scrubber);
          KR.initScrubberHider();
      }
  );
}

KR.init = function (data) {
  KR.bookData = KR.createBookData(data);
  KR.initReader();
  KR.initTitle();
  KR.initTOC();
  KR.bindEvents();
  KR.swipeEvents();
};
