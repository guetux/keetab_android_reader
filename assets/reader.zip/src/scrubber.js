
var KR = KR === undefined ? {} : KR;

KR.initScrubber = function () {
  // properties
  var $container= $('#scrubber-container');
  var $scrubber = $('#scrubber');
  var moveActive = false;

  function startFadeOutTimer() {
    $container.timer = setTimeout(function () {
      $container.hide();
    }, 3000);
  }

  function clearFadeOutTimer() {
    if ($container.timer !== undefined) {
      clearTimeout($container.timer);
      delete $container.timer;
    }
  }

  function onPageTurn() {
    var place = KR.reader.getPlace();
    var through = place.percentageOfBook();
    var percent = Math.round(through * 100);
    if (place.onFirstPageOfBook())
      percent = 0;
    $scrubber.val(percent);

    if(!moveActive) {
      clearFadeOutTimer();
      $container.show();
      startFadeOutTimer();
    }
  }

  function onSliderValueChanged() {
    var goToPercent = $scrubber.val() / 100;
    var locus = Monocle.Place.percentOfBookToLocus(KR.reader, goToPercent);
    KR.reader.moveTo(locus);
  }

  function onMoveStarted() {
    moveActive = true;
    clearFadeOutTimer();
  }

  function onMoveEnd() {
    moveActive = false;
    startFadeOutTimer();
  }

  /* Bind events */

  // When page is turned
  KR.reader.listen('monocle:turn', onPageTurn);

  // Check Movement
  $scrubber.change(onSliderValueChanged);

  // Don't hide wenn moved
  $scrubber.bind('touchstart mousedown', onMoveStarted);
  $scrubber.bind('touchend mouseup', onMoveEnd);
};