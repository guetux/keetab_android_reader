

$(function () {
    $('.tabs-nav a').click(function () {
        var $tabsnav = $(this).parent('.tabs-nav');
        var $target = $($(this).attr('href'));
        var $tabs = $target.parent('.tabs-content');

        $tabsnav.children().removeClass('active');
        $(this).addClass('active');

        $tabs.children().hide();
        $target.show();
        return false;
    });

    $('.tabs-nav a:first-child').click();
});