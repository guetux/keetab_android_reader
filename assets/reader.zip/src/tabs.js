
function switchToTab(tabId) {
    var $target = $(tabId);
    var $tabs = $target.parent('.tabs-content');
    var $tabsnav = $tabs.prev('.tabs-nav');

    $tabsnav.children().removeClass('active');
    $tabsnav.find('a[href="'+tabId+'"]').addClass('active');

    $tabs.children().hide();
    $target.show();
    return false;
}

$(function () {
    $('.tabs-nav a').click(function () {
        var tabId = $(this).attr('href');
        switchToTab(tabId);
    });

    $('.tabs-nav a:first-child').click();
});